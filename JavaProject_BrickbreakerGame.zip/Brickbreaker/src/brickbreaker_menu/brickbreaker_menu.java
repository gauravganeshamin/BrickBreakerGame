package brickbreaker_menu;

import java.sql.*;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.swing.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

class MyGUI extends JFrame {
    private static final long serialVersionUID = 1L;

    public MyGUI() {
        super("Welcome to the brickbreaker game");
        setSize(400, 200);
        setLayout(new GridLayout(3, 1));
    }
}

class Button1Listener implements ActionListener {
    public String username;
    public Button1Listener(String uname){
        username=uname;
    }
    public void actionPerformed(ActionEvent e) {
        try {
        	// //String[] cmd = {"java","-cp","C:\\Users\\Gaurav Ganesh Amin\\eclipse-workspace-Brickbreaker-Project\\Brickbreaker\\src\\brickbreaker_medium","brickbreaker_medium.brickbreaker_medium"};
            // String[] cmd = {"java","-cp","C:\\Users\\HP\\Downloads\\Brickbreaker_menu_notworking_latest\\Brickbreaker\\src\\brickbreaker_medium","brickbreaker_medium.brickbreaker_medium"};
            // //Runtime.getRuntime().exec("java -cp C:\\Users\\Gaurav Ganesh Amin\\eclipse-workspace-Brickbreaker-Project\\Brickbreaker\\src\\brickbreaker_easy brickbreaker_easy.brickbreaker_easy");
        	// Runtime.getRuntime().exec(cmd);

            String[] cmd2={"java", "-cp", "..\\..\\lib\\mysql-connector-j-8.0.33.jar;.","brickbreaker_easy.brickbreaker_easy",username};
        	Runtime.getRuntime().exec(cmd2);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}

class Button2Listener implements ActionListener {
    public String username;
    public Button2Listener(String uname){
        username=uname;
    }
    public void actionPerformed(ActionEvent e) {
        try {
        	//String[] cmd = {"java","-cp","C:\\Users\\Gaurav Ganesh Amin\\eclipse-workspace-Brickbreaker-Project\\Brickbreaker\\src\\brickbreaker_medium","brickbreaker_medium.brickbreaker_medium"};
            // String[] cmd = {"java","-cp","C:\\Users\\HP\\Downloads\\Brickbreaker_menu_notworking_latest\\Brickbreaker\\src\\brickbreaker_medium","brickbreaker_medium.brickbreaker_medium"};
            String path = System.getProperty("user.dir");
            System.out.println(path);

            String[] cmd2={"java", "-cp", "..\\..\\lib\\mysql-connector-j-8.0.33.jar;.","brickbreaker_medium.brickbreaker_medium",username};
            //Runtime.getRuntime().exec("java -cp C:\\Users\\Gaurav Ganesh Amin\\eclipse-workspace-Brickbreaker-Project\\Brickbreaker\\src\\brickbreaker_easy brickbreaker_easy.brickbreaker_easy");
        	Runtime.getRuntime().exec(cmd2);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}

class Button3Listener implements ActionListener {
    public String username;
    public Button3Listener(String uname){
        username=uname;
    }
    public void actionPerformed(ActionEvent e) {
        // try {
        //     Runtime.getRuntime().exec("java -cp C:\\Users\\Gaurav Ganesh Amin\\eclipse-workspace-Brickbreaker-Project\\Brickbreaker\\src brickbreaker_difficult.brickbreaker_difficult");
        // } catch (IOException ex) {
        //     ex.printStackTrace();
        // }
        try {
        	// //String[] cmd = {"java","-cp","C:\\Users\\Gaurav Ganesh Amin\\eclipse-workspace-Brickbreaker-Project\\Brickbreaker\\src\\brickbreaker_medium","brickbreaker_medium.brickbreaker_medium"};
            // String[] cmd = {"java","-cp","C:\\Users\\HP\\Downloads\\Brickbreaker_menu_notworking_latest\\Brickbreaker\\src\\brickbreaker_medium","brickbreaker_medium.brickbreaker_medium"};
            // //Runtime.getRuntime().exec("java -cp C:\\Users\\Gaurav Ganesh Amin\\eclipse-workspace-Brickbreaker-Project\\Brickbreaker\\src\\brickbreaker_easy brickbreaker_easy.brickbreaker_easy");
        	// Runtime.getRuntime().exec(cmd);

            String[] cmd2={"java", "-cp", "..\\..\\lib\\mysql-connector-j-8.0.33.jar;.","brickbreaker_difficult.brickbreaker_difficult",username};
        	Runtime.getRuntime().exec(cmd2);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}

public class brickbreaker_menu {
    public static void game_mode_menu(String username){
        MyGUI frame = new MyGUI();
        JButton button1 = new JButton("Easy");
        button1.addActionListener(new Button1Listener(username));

        JButton button2 = new JButton("Medium");
        button2.addActionListener(new Button2Listener(username));

        JButton button3 = new JButton("Difficult");
        button3.addActionListener(new Button3Listener(username));

        frame.add(button1);
        frame.add(button2);
        frame.add(button3);
        frame.setLocation(500, 275);
        frame.setVisible(true);
    }
    public static void input_username(Connection connection){
        String username="";
        ResultSet resultSet;
        JTextField xField  = new JTextField(5);

        JPanel myPanel = new JPanel();
        myPanel.add(new JLabel("Username:"));
        myPanel.add(xField);


        int result = JOptionPane.showConfirmDialog(null, myPanel, 
        "Enter Username", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            username=xField.getText();
            // resultSet = statement.executeQuery(
            // "select username from users where username=?");
            String insertStr="select username from users where username=?";
            try (PreparedStatement pst = connection.prepareStatement(insertStr)) {
                pst.setString(1, username);
                resultSet=pst.executeQuery();
                if(resultSet.next()){
                    System.out.println("User exists!");
                    game_mode_menu(username);
                    // System.out.println(score);
                }
                else{
                    not_exist(connection);
                }
            }
            catch (Exception exception) {
                System.out.println(exception);
            }
        }
        else
        if(result == JOptionPane.CANCEL_OPTION){
            parent_dialog_box(connection);
        }
    }

    public static void new_user(Connection connection){
        ResultSet resultSet;
        String username="";
        JTextField xField  = new JTextField(5);

        JPanel myPanel = new JPanel();
        myPanel.add(new JLabel("Username"));
        myPanel.add(xField);

        int result = JOptionPane.showConfirmDialog(null, myPanel, 
        "Enter preferred Username", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            username=xField.getText();
            // resultSet = statement.executeQuery(
            // "select username from users where username=?");
            String insertStr="select username from users where username=?";
            String insertStr2="insert into users (username) values(?)";
            try (PreparedStatement pst = connection.prepareStatement(insertStr)) {
                pst.setString(1, username);
                resultSet=pst.executeQuery();
                if(resultSet.next()){
                    System.out.println("Username already taken!");
                    already_exists(connection);
                    // System.out.println(score);
                }
                else{
                    // Add username to database and redirect to game menu
                    try (PreparedStatement pst2 = connection.prepareStatement(insertStr2)) {
                        pst2.setString(1, username);
                        pst2.executeUpdate();
                        game_mode_menu(username);
                    }
                }
            }
            catch (Exception exception) {
                System.out.println(exception);
            }
        }
        else
        if(result == JOptionPane.CANCEL_OPTION){
            parent_dialog_box(connection);
        }
    }

    public static void already_exists(Connection connection){
        System.out.println("User already exists!");
        JFrame f=new JFrame();  
        JOptionPane.showMessageDialog(f,"Username already taken!","Alert",JOptionPane.WARNING_MESSAGE);
        new_user(connection);
    }
    public static void not_exist(Connection connection){
        System.out.println("User dosent exist!");
        JFrame f=new JFrame();  
        JOptionPane.showMessageDialog(f,"User dosent exist!","Alert",JOptionPane.WARNING_MESSAGE);
        parent_dialog_box(connection);
    }

    public static void parent_dialog_box(Connection connection){
        ResultSet resultSet;
        /* Simple JOptionPane ShowOptionDialogJava example */    
        String[] options = { "Existing User", "New User" };
        var selection = JOptionPane.showOptionDialog(null, "Select the appropriate option", "BRICKBREAKER", 
                                                        0, 1, null, options, options[0]);
        String username="";
        
        if (selection == 0) {
            // String username=JOptionPane.showInputDialog(null, "Existing user");
            // System.out.println(username);
            input_username(connection);
        }
        if (selection == 1) { 
            new_user(connection);
        }
    }

    public static void main(String[] args) {
        Connection connection;
        Statement statement;
        
        connection = null;
        // Compilation commands
        try{
            String[] cmd_1={"javac", "-d", ".", "-cp", "..\\..\\lib\\mysql-connector-j-8.0.33.jar;.", "../brickbreaker_easy/brickbreaker_easy.java"};
            Runtime.getRuntime().exec(cmd_1);

            String[] cmd_2={"javac", "-d", ".", "-cp", "..\\..\\lib\\mysql-connector-j-8.0.33.jar;.", "../brickbreaker_medium/brickbreaker_medium.java"};
            Runtime.getRuntime().exec(cmd_2);

            String[] cmd_3={"javac", "-d", ".", "-cp", "..\\..\\lib\\mysql-connector-j-8.0.33.jar;.", "../brickbreaker_difficult/brickbreaker_difficult.java"};
            Runtime.getRuntime().exec(cmd_3);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }

        // Object[] options1 = { "Existing User", "New User"};

        // JPanel panel = new JPanel();
        // JFrame f;  
        // panel.add(new JLabel("WELCOME TO BRICKBREAKER!"));
        // // JTextField textField = new JTextField(10);
        // // panel.add(textField);

        // int result = JOptionPane.showOptionDialog(null, panel, "Enter a Number",
        //         JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE,
        //         null, options1, null);
        // if (result == JOptionPane.YES_OPTION){
        //     //JOptionPane.showMessageDialog(null, textField.getText());
        //      f=new JFrame();   
        //     String name=JOptionPane.showInputDialog(f,"Enter Name");  
        //     System.out.println(name);    
        // }


        try {
            // below two lines are used for connectivity.
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/brickbreaker",
                "root", "");

            // mydb is database
            // mydbuser is name of database
            // mydbuser is password of database
            statement = connection.createStatement();
            // 	System.out.println("Mode : " + mode + ", Score : " + score);
            // }
        }
        catch (Exception exception) {
            System.out.println(exception);
        }

        parent_dialog_box(connection);

    }
}
