// import java.io.BufferedReader;
// import java.io.IOException;
// import java.io.InputStreamReader;
// import java.io.PrintWriter;
// import java.net.Socket;

// public class clientSide {
//     private final String host;
//     private final int port;
//     private Socket socket;
//     private PrintWriter out;
//     private BufferedReader in;

//     public clientSide(String host, int port) {
//         this.host = host;
//         this.port = port;
//     }

//     public void start() throws IOException {
//         socket = new Socket(host, port);
//         System.out.println("Connected to server");

//         out = new PrintWriter(socket.getOutputStream(), true);
//         in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

//         new Thread(() -> {
//             String inputLine;
//             try {
//                 while ((inputLine = in.readLine()) != null) {
//                     System.out.println("Received from server: " + inputLine);
// 					System.out.println(Thread.currentThread().getId());
//                     // handle server input here
//                 }
//             } catch (IOException e) {
//                 e.printStackTrace();
//             }
//         }).start();
//     }

//     public void send(String message) {
//         out.println(message);
//     }

//     public static void main(String[] args) throws IOException {
//         clientSide client = new clientSide("localhost", 5000);
//         client.start();

//         // example usage: send a message to the server
//         client.send("Hello, server!");
// 		// client.send(Thread.currentThread().getId());
//     }
// }

// import java.io.*;
// import java.net.*;

// public class MultiplayerClient {
//     private final String serverHost;
//     private final int serverPort;
//     private BufferedReader in;
//     private PrintWriter out;

//     public MultiplayerClient(String serverHost, int serverPort) {
//         this.serverHost = serverHost;
//         this.serverPort = serverPort;
//     }

//     // public void start() throws IOException {
//     //     try (Socket socket = new Socket(serverHost, serverPort);
//     //          out = new PrintWriter(socket.getOutputStream(), true);
//     //          in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
//     //          BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in))) {

//     //         System.out.println("Connected to server: " + serverHost + ":" + serverPort);
//     //         System.out.println("Thread ID: " + Thread.currentThread().getId());
//     //         new Thread(new ServerListener()).start();
//     //         String userInput;
//     //         while ((userInput = stdIn.readLine()) != null) {
//     //             out.println(userInput);
//     //             String response = in.readLine();
//     //             System.out.println("Server response: " + response);
//     //         }
//     //     } catch (IOException e) {
//     //         e.printStackTrace();
//     //     }
//     // }

//     public void start() throws IOException {
//         Socket socket = new Socket(serverHost, serverPort);
//         out = new PrintWriter(socket.getOutputStream(), true);
//         in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
//         BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));

//         System.out.println("Connected to server: " + serverHost + ":" + serverPort);
//         // System.out.println("Thread ID: " + Thread.currentThread().getId());
//         new Thread(new ServerListener()).start();
//         String userInput;
//         while ((userInput = stdIn.readLine()) != null) {
//             out.println(userInput);
//             String response = in.readLine();
//             System.out.println("Server response: " + response);
//         }
//         // while (true) {
//         //     // Read a line of input from the user and send it to the server
//         //     String userInput = stdIn.readLine();
//         //     if (userInput == null) {
//         //         break;
//         //     }
//         //     out.println(userInput);

//         //     // Read responses from the server and print them
//         //     String response;
//         //     while ((response = in.readLine()) != null) {
//         //         System.out.println("Server response: " + response);
//         //     }
//         // }

//         in.close();
//         out.close();
//         stdIn.close();
//         socket.close();
//     }


//     private class ServerListener implements Runnable {
//         @Override
//         public void run() {
//             try {
//                 String inputLine;
//                 while ((inputLine = in.readLine()) != null) {
//                     System.out.println("Received message from server: " + inputLine);
//                     break;
//                 }
//             } catch (IOException e) {
//                 e.printStackTrace();
//             }
//         }
//     }

//     public static void main(String[] args) {
//         MultiplayerClient client = new MultiplayerClient("localhost", 5000);
//         new Thread(() -> {
//             try {
//                 client.start();
//             } catch (IOException e) {
//                 e.printStackTrace();
//             }
//         }).start();
//     }
// }




package brickbreaker_multiplayer;

import java.io.*;
import java.net.*;

public class MultiplayerClient {
    private final String serverHost;
    private final int serverPort;
    private BufferedReader in;
    private PrintWriter out;

    public MultiplayerClient(String serverHost, int serverPort) {
        this.serverHost = serverHost;
        this.serverPort = serverPort;
    }

    public void start() throws IOException {
        Socket socket = new Socket(serverHost, serverPort);
        out = new PrintWriter(socket.getOutputStream(), true);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Connected to server: " + serverHost + ":" + serverPort);

        // Start a new thread to listen for incoming messages from the server
        Thread listenerThread = new Thread(new ServerListener());
        listenerThread.start();

        String userInput;
        while ((userInput = stdIn.readLine()) != null) {
            // Send the user input to the server
            out.println(userInput);
        }

        // Clean up resources
        listenerThread.interrupt();
        in.close();
        out.close();
        stdIn.close();
        socket.close();
    }

    private class ServerListener implements Runnable {
        @Override
        public void run() {
            try {
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    System.out.println("Received message from server: " + inputLine);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        MultiplayerClient client = new MultiplayerClient("localhost", 5000);
        new Thread(() -> {
            try {
                client.start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }
}

