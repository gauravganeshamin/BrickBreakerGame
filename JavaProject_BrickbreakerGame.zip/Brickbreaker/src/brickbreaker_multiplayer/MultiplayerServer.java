// import java.io.BufferedReader;
// import java.io.IOException;
// import java.io.InputStreamReader;
// import java.io.PrintWriter;
// import java.net.ServerSocket;
// import java.net.Socket;

// public class serverSide {
//     private ServerSocket serverSocket;
//     private final int port;

//     public serverSide(int port) {
//         this.port = port;
//     }

//     public void start() throws IOException {
//         serverSocket = new ServerSocket(port);
//         System.out.println("Server started on port " + port);

//         while (true) {
//             Socket clientSocket = serverSocket.accept();
//             System.out.println("New client connected: " + clientSocket.getInetAddress().getHostAddress());

//             ClientHandler clientHandler = new ClientHandler(clientSocket);
//             new Thread(clientHandler).start();
//         }
//     }

//     public static void main(String[] args) throws IOException {
//         serverSide server = new serverSide(5000);
//         server.start();
//     }
// }

// class ClientHandler implements Runnable {
//     private final Socket clientSocket;
//     private PrintWriter out;
//     private BufferedReader in;

//     public ClientHandler(Socket clientSocket) {
//         this.clientSocket = clientSocket;
//     }

//     @Override
//     public void run() {
//         try {
//             out = new PrintWriter(clientSocket.getOutputStream(), true);
//             in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

//             String inputLine;
//             while ((inputLine = in.readLine()) != null) {
//                 System.out.println("Received from client: " + inputLine);

//                 // handle client input here

//                 out.println("Server received: " + inputLine);
//             }
//         } catch (IOException e) {
//             e.printStackTrace();
//         } finally {
//             try {
//                 in.close();
//                 out.close();
//                 clientSocket.close();
//             } catch (IOException e) {
//                 e.printStackTrace();
//             }
//         }
//     }

//     public void send(String message) {
//         out.println(message);
//     }
// }
//package brickbreaker_multiplayer;

import java.io.*;
import java.net.*;
import java.util.*;

public class MultiplayerServer {
    private  ServerSocket serverSocket;
    private final int port;
    private final Map<UUID, ClientHandler> clients;

    public MultiplayerServer(int port) {
        this.port = port;
        this.clients = new HashMap<>();
    }

    public void start() throws IOException {
        serverSocket = new ServerSocket(port);
        System.out.println("Server started on port " + port);

        while (true) {
            Socket clientSocket = serverSocket.accept();
            System.out.println("New client connected: " + clientSocket.getInetAddress().getHostAddress());

            UUID clientId = UUID.randomUUID();
            ClientHandler clientHandler = new ClientHandler(clientId, clientSocket);
            clients.put(clientId, clientHandler);

            new Thread(clientHandler).start();
        }
    }

    public void stop() throws IOException {
        serverSocket.close();
    }
    public void sendToAll(String message) {
        for (ClientHandler client : clients.values()) {
            // System.out.println("Sending to all clients"+client);
            client.out.println(message);
        }

    }
    public void sendToOthers(String message,UUID sender,Boolean flag) {
        for (ClientHandler client : clients.values()) {
            if(clients.size()==1&&!flag){
                client.out.println("First player");
                flag=true;
            }
            if(clients.size()>1){
                client.out.println("2 participants");
            }
            if(client.clientId==sender){
                continue;
            }
            // System.out.println("Sending to all clients"+client);
            client.out.println(message);
        }
    }

    public static void main(String[] args) throws IOException {
        MultiplayerServer server = new MultiplayerServer(5006);
        server.start();
    }

    private class ClientHandler implements Runnable {
        private final UUID clientId;
        private final Socket clientSocket;
        private PrintWriter out;
        private BufferedReader in;
        public boolean flag=false;;

        public ClientHandler(UUID clientId, Socket clientSocket) {
            this.clientId = clientId;
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
            try {
                out = new PrintWriter(clientSocket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                String inputLine;
                while ((inputLine = in.readLine().trim()) != null) {
                    System.out.println("Received message from client " + clientId + ": " + inputLine);
                    if(inputLine.startsWith("final score")){
                        sendToAll(inputLine);
                    }
                    else{
                        sendToOthers(inputLine,clientId,flag);
                    }
                }

                System.out.println("Client " + clientId + " disconnected: " + clientSocket.getInetAddress().getHostAddress());
                clients.remove(clientId);
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void send(String message) {
            out.println(message);
        }
    }
}


