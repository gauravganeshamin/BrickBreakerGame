package brickbreaker_multiplayer;

import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

class MapGenerator_easy {
	
	public int map [][];
	public int brickWidth;
	public int brickHeight;
	
	// this creates the brick of size 3x7
	public MapGenerator_easy(int row, int col) {
		map = new int [row][col];
		for (int i = 0; i < map.length; i++) { 
			for (int j=0; j< map[0].length;j++) {
				map[i][j] = 1;
			}
		}
		
		brickWidth = 70;
		brickHeight = 40;
	}
	
	// this draws the bricks
	public void draw(Graphics2D g) {
		for (int i = 0; i <map.length; i++) {
			for (int j=0; j< map[0].length;j++) {
				if(map[i][j] > 0) {
					g.setColor(new Color(0X009f71)); // brick color
					g.fillRect(j*brickWidth + 70, i*brickHeight + 120, brickWidth, brickHeight);
					
					g.setStroke(new BasicStroke(4));
					g.setColor(Color.BLACK);
					g.drawRect(j*brickWidth + 70, i*brickHeight + 120, brickWidth, brickHeight);
				}
			}
			
		}
	}
	
	// this sets the value of brick to 0 if it is hit by the ball
	public void setBrickValue(int value, int row, int col) {
		map[row][col] = value;
	}

}

// class MultiplayerClient {
//     protected final String serverHost;
//     protected final int serverPort;
//     protected BufferedReader in;
//     protected PrintWriter out;

//     public MultiplayerClient(String serverHost, int serverPort) {
//         this.serverHost = serverHost;
//         this.serverPort = serverPort;
//     }

//     public void start() throws IOException {
//         Socket socket = new Socket(serverHost, serverPort);
//         out = new PrintWriter(socket.getOutputStream(), true);
//         in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
//         BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));

//         System.out.println("Connected to server: " + serverHost + ":" + serverPort);

//         // Start a new thread to listen for incoming messages from the server
//         Thread listenerThread = new Thread(new ServerListener());
//         listenerThread.start();

//         String userInput;
//         while ((userInput = stdIn.readLine()) != null) {
//             // Send the user input to the server
//             out.println(userInput);
//         }

//         // Clean up resources
//         listenerThread.interrupt();
//         in.close();
//         out.close();
//         stdIn.close();
//         socket.close();
//     }

//     protected class ServerListener implements Runnable {
//         @Override
//         public void run() {
//             try {
//                 String inputLine;
//                 while ((inputLine = in.readLine()) != null) {
//                     System.out.println("Received message from server: " + inputLine);
//                 }
//             } catch (IOException e) {
//                 e.printStackTrace();
//             }
//         }
//     }
// }

class GamePlay_easy extends JPanel implements KeyListener, ActionListener  {
	private static final long serialVersionUID = 1L;
	private boolean play = true;
	private int score = 0;
	
	private int totalBricks = 21;
	
	protected Timer timer;
	private int delay = 50;
	
	private int playerX = 310;
	
	private int ballposX = 250;
	private int ballposY = 350;
	private int ballXdir = -1;
	private int ballYdir = -2;
	
	private MapGenerator_easy map;
	private volatile boolean running = false;
    private Thread gameThread;
	public int all_time_highest_score=0;
	public int user_highest_score=0;
	public Connection connection;
	public Statement statement;
	public ResultSet resultSet;
	public ResultSet resultSet2;
	public String username;

	protected final String serverHost;
    protected final int serverPort;
    protected BufferedReader in;
    protected PrintWriter out;
	protected Socket socket;
	protected ActionListener lstnr;
	protected int flag=0; //flag=0 (only 1 participant)
	protected int final_score=0;
	protected Graphics g;
	protected boolean finalScoreSent = false; // Initialize flag to false
	protected boolean req_participants = false;
	protected String verd="";
	protected boolean flag_verdict=false;
	protected boolean flag_opponent=false;
	protected String opponent="";
	protected String opponent_score="";
	public GamePlay_easy(String uname,String serverHost, int serverPort,JFrame frame) {
		this.serverHost = serverHost;
        this.serverPort = serverPort;
		g = frame.getGraphics();
		new Thread(() -> {
            try {
                start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();

		connection = null;
		username=uname;
		try {
			// below two lines are used for connectivity.
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/brickbreaker",
				"root", "");

			// mydb is database
			// mydbuser is name of database
			// mydbuser is password of database
			statement = connection.createStatement();
			resultSet = statement.executeQuery(
				"select max(score) from scores_easy");
            //String mode;
            int score;
			//while (resultSet.next()) {
                //mode = resultSet.getString("mode").trim();
			if(resultSet.next()){
				score = resultSet.getInt("max(score)");
				all_time_highest_score=score;
				// System.out.println(score);
			}
			// System.out.println(all_time_highest_score);
			
			String insertStr="select score from scores_easy where username=?";
			// 	System.out.println("Mode : " + mode + ", Score : " + score);
			// }
			String a=username;
			try (PreparedStatement pst = connection.prepareStatement(insertStr)) {
                pst.setString(1, a);
                resultSet2=pst.executeQuery();
				if(resultSet2.next()){
					user_highest_score=resultSet2.getInt("score");
					// System.out.println(score);
                }
                else{
                    user_highest_score=0;
                }
            }
			catch (Exception exception) {
				System.out.println(exception);
			}
		}
		catch (Exception exception) {
			System.out.println(exception);
		}

		System.out.println(flag);
		map = new MapGenerator_easy(3, 7);
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		lstnr=this;
		

	}


	public void start() throws IOException {
		// System.out.println("listener");
		socket = new Socket(serverHost, serverPort);
		out = new PrintWriter(socket.getOutputStream(), true);
		in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
		out.println("Username "+username);
		out.println("score "+score);
		System.out.println("Connected to server: " + serverHost + ":" + serverPort);

		// Start a new thread to listen for incoming messages from the server
		Thread listenerThread = new Thread(new ServerListener());
		listenerThread.start();

		// String userInput;
		// while ((userInput = stdIn.readLine()) != null) {
		// 	// Send the user input to the server
		// 	out.println(userInput);
		// // }
		// out.println("Hello1");
		// System.out.println("test");
		// System.out.println("out0"+out);
		// System.out.println("out1"+this.out);
		// Clean up resources
		// listenerThread.interrupt();
		// in.close();
		// out.close();
		// stdIn.close();
		// socket.close();
    }

    protected class ServerListener implements Runnable {
        @Override
        public void run() {
            try {
                String inputLine;
                 while ((inputLine = in.readLine().trim()) != null) {
				 	// inputLine = in.readLine();
					System.out.println(inputLine);
					try{
						if(inputLine.equals("First player")){
							ballposX=100;
						}
						if(inputLine.equals("2 participants")&&!req_participants){
							// System.out.println("flag toggle");
							flag=1;
							out.println("Username "+username);
							if(flag!=0){
								Thread.sleep(5000);
								timer = new Timer(delay, lstnr);
								timer.start();
							}
							req_participants=true;
						}
						if(inputLine.startsWith("final score")){
							if(flag_verdict==false){
								verd=inputLine;
								flag_verdict=true;
							}
							ballposY=572;
							play = false;
							ballXdir = 0;
							ballYdir = 0;
							//Graphics g=new Graphics();
							g.setColor(Color.WHITE);
							g.setFont(new Font("MV Boli", Font.BOLD, 30));
							g.drawString("Game Over, Score: " + score, 190, 350);
							
							g.setFont(new Font("MV Boli", Font.BOLD, 20));
							
						}
						if(inputLine.startsWith("Username")){
							if(flag_opponent==false){
								opponent=inputLine;
								String[] arrOfStr = opponent.split(" ");
								opponent=arrOfStr[1];
								flag_opponent=true;
							}
						}
						if(inputLine.startsWith("score")){
							opponent_score=inputLine;
							String[] arrOfStr = opponent_score.split(" ");
							opponent_score=arrOfStr[1];
						}

					}
					catch (Exception e) {
						// catching the exception
						System.out.println(e);
					}
					
                     System.out.println(inputLine);
                 }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
	
	//  public void start() {
	//         if (running) {
	//             return;
	//         }
	//         running = true;
	//         gameThread = new Thread(() -> {
	//             while (running) {
	//                 update();
	//                 repaint();
	//                 try {
	//                     Thread.sleep(delay);
	//                 } catch (InterruptedException e) {
	//                     e.printStackTrace();
	//                 }
	//             }
	//         });
	//         gameThread.start();
	//     }

	//   public void stop() {
	//         running = false;
	//         try {
	//             gameThread.join();
	//         } catch (InterruptedException e) {
	//             e.printStackTrace();
	//         }
	//    }
	  
	   private void update() {
		    // move the ball
		    ballposX += ballXdir;
		    ballposY += ballYdir;
		    
		    // detect collisions with the walls
		    if (ballposX < 0) {
		        ballXdir = -ballXdir;
		    }
		    if (ballposY < 0) {
		        ballYdir = -ballYdir;
		    }
		    if (ballposX > 670) {
		        ballXdir = -ballXdir;
		    }
		    
		    // detect collisions with the bricks
		    for (int i = 0; i < map.map.length; i++) {
		        for (int j = 0; j < map.map[0].length; j++) {
		            if (map.map[i][j] > 0) {
		                int brickX = j * map.brickWidth + 70;
		                int brickY = i * map.brickHeight + 120;
		                int brickWidth = map.brickWidth;
		                int brickHeight = map.brickHeight;
		                
		                Rectangle rect = new Rectangle(brickX, brickY, brickWidth, brickHeight);
		                Rectangle ballRect = new Rectangle(ballposX, ballposY, 20, 20);
		                Rectangle brickRect = rect;
		               // try{
							if (ballRect.intersects(brickRect)) {
								//out = new PrintWriter(socket.getOutputStream(), true);
								map.setBrickValue(0, i, j);
								totalBricks--;
								score += 5;
								
								if (ballposX + 19 <= brickRect.x || ballposX + 1 >= brickRect.x + brickRect.width) {
									ballXdir = -ballXdir;
								} else {
									ballYdir = -ballYdir;
								}
							}
						//}
						// catch (IOException e) {
               			// 	e.printStackTrace();
            			// }
		            }
		        }
		    }
		    
		    repaint();
		}
   

	public void paint(Graphics g) {
		
		//background color
		g.setColor(Color.green.brighter());
		g.fillRect(1, 1, 692, 592);
		
		map.draw((Graphics2D)g);
		
		g.fillRect(0, 0, 3, 592);
		g.fillRect(0, 0, 692, 3);
		g.fillRect(691, 0, 3, 592);
		
		g.setColor(Color.green.darker());
		g.fillRect(playerX, 550, 100, 12);
		
		g.setColor(Color.GRAY);  // ball color
		g.fillOval(ballposX, ballposY, 20, 20);
		
		g.setColor(Color.white);
		g.setFont(new Font("MV Boli", Font.BOLD, 25));
		g.drawString(username+" score: " +score, 50, 30);
		g.drawString(opponent+" score: " +opponent_score, 400, 30);
		g.drawString("All-Time Highest score: " + all_time_highest_score, 200, 60);
		
		if (totalBricks <= 0) { // if all bricks are destroyed then you win
			play = false;
			ballXdir = 0;
			ballYdir = 0;
			g.setColor(Color.white);
			g.setFont(new Font("MV Boli", Font.BOLD, 30));
			g.drawString("You Won, Score: " + score, 190, 300);
			
			g.setFont(new Font("MV Boli", Font.BOLD, 20));
			g.drawString("Press Enter to Restart.", 230, 350);
		}
		
		if(ballposY > 570) { // if ball goes below the paddle then you lose 
			if(!finalScoreSent){
				final_score=score;
				out.println("final score "+username+" lost "+final_score);
				finalScoreSent = true;
			}
			String[] arrOfStr = verd.split(" ");
			String verdict="";
			int rand_integer_test=Integer.parseInt(arrOfStr[4]);
			 if(score<=rand_integer_test&&arrOfStr[2].equals(username)){
				verdict="YOU LOSE!";
			 }
			 else{
				verdict="YOU WIN!";
			 }
			 //System.out.println(verdict);
			// try{
			// 	in.close();
			// 	out.close();
			// }
			// catch (IOException e) {
            //     e.printStackTrace();
			// }
			String a=username;
            int b=score;
            String insertStr = "INSERT INTO scores_easy(username,score) VALUES(?, ?) ON DUPLICATE KEY UPDATE score= GREATEST(score, ?)";
            try (PreparedStatement pst = connection.prepareStatement(insertStr)) {
                pst.setString(1, a);
                pst.setInt(2, b);
                pst.setInt(3, b);
                pst.executeUpdate();
            }
			catch (Exception exception) {
				System.out.println(exception);
			}

			// resultSet.close();
			// statement.close();
			// connection.close();
			play = false;
			ballXdir = 0;
			ballYdir = 0;
			g.setColor(Color.WHITE);
			g.setFont(new Font("MV Boli", Font.BOLD, 30));
			g.drawString("Game Over, Score: " + score, 190, 350);
			g.drawString(verdict, 220, 390);
			g.setFont(new Font("MV Boli", Font.BOLD, 20));
			// g.drawString("Press Enter to Restart", 230, 400);
		g.dispose();
		}
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		timer.start();
		if(play) {
			// Ball - Pedal  interaction 
			if(new Rectangle(ballposX, ballposY, 20, 20).intersects(new Rectangle(playerX, 550, 100, 8))) {
				ballYdir = - ballYdir;
			}
			for( int i = 0; i<map.map.length; i++) { // Ball - Brick interaction
				for(int j = 0; j<map.map[0].length; j++) {  // map.map[0].length is the number of columns
					if(map.map[i][j] > 0) {
						int brickX = j*map.brickWidth + 70;
						int brickY = i*map.brickHeight + 120;
						int brickWidth= map.brickWidth;
						int brickHeight = map.brickHeight;
						
						Rectangle rect = new Rectangle(brickX, brickY, brickWidth, brickHeight);
						Rectangle ballRect = new Rectangle(ballposX, ballposY, 20,20);
						Rectangle brickRect = rect;
						
						if(ballRect.intersects(brickRect) ) {
							map.setBrickValue(0, i, j);
							totalBricks--;
							// out.println("Success");
							score+=5;
							out.println("score "+score);
							
							if(ballposX + 19 <= brickRect.x || ballposX +1 >= brickRect.x + brickRect.width) 
								ballXdir = -ballXdir;
							 else {
								ballYdir = -ballYdir;
							}
						}
						
					}
					
				}
			}
			
			ballposX += ballXdir;
			ballposY += ballYdir;
			if(ballposX < 0) { // if ball hits the left wall then it bounces back
				ballXdir = -ballXdir;
			}
			if(ballposY < 0) {  // if ball hits the top wall then it bounces back
				ballYdir = -ballYdir;
			}
			if(ballposX > 670) { // if ball hits the right wall then it bounces back
				ballXdir = -ballXdir;  
			
			}
			
		}
		
		
		repaint();

	}
	

	@Override
	public void keyTyped(KeyEvent arg0) {
		
	}
	
	@Override
	public void keyPressed(KeyEvent arg0) {
		if(arg0.getKeyCode() == KeyEvent.VK_RIGHT) { // if right arrow key is pressed then paddle moves right
			if(playerX >= 600) {
				playerX = 600;
			} else {
				moveRight();
					
			}
		}
		if(arg0.getKeyCode() == KeyEvent.VK_LEFT) { // if left arrow key is pressed then paddle moves left
			if(playerX < 10) {
				playerX = 10;
			} else {
				moveLeft();
					
			}
		}
		
		// if(arg0.getKeyCode() == KeyEvent.VK_ENTER) { // if enter key is pressed then game restarts
		// 	if(!play) {
		// 		// ResultSet resultSet;
		// 		// statement = connection.createStatement();
		// 		try{
		// 			resultSet = statement.executeQuery(
		// 				"select max(score) from scores_medium");
		// 			//String mode;
		// 			int score;
		// 			//while (resultSet.next()) {
		// 				//mode = resultSet.getString("mode").trim();
		// 			if(resultSet.next()){
		// 				score = resultSet.getInt("max(score)");
		// 				all_time_highest_score=score;
		// 				// System.out.println(score);
		// 			}

		// 			String insertStr="select score from scores_medium where username=?";
		// 			// 	System.out.println("Mode : " + mode + ", Score : " + score);
		// 			// }
		// 			String a=username;
		// 			PreparedStatement pst = connection.prepareStatement(insertStr);
		// 			pst.setString(1, a);
		// 			resultSet2=pst.executeQuery();
		// 			if(resultSet2.next()){
		// 				user_highest_score=resultSet2.getInt("score");
		// 				// System.out.println(score);
		// 			}
		// 			else{
		// 				user_highest_score=0;
		// 			}

		// 		}
		// 		catch (Exception exception) {
		// 			System.out.println(exception);
		// 		}
		// 		play = true;
		// 		ballposX = 250;
		// 		ballposY = 350;
		// 		ballXdir = 1;
		// 		ballYdir = 2;
		// 		score = 0;
		// 		totalBricks = 32;
		// 		map = new MapGenerator_easy(4,8);
				
		// 		repaint();
		// 	}
		// }
		
	}	
		public void moveRight() { // paddle moves right by 50 pixels
			play = true;
			playerX += 50;
		}
		public void moveLeft() { // paddle moves left by 50 pixels
			play = true;
			playerX -= 50;
		}
		
	

	@Override
	public void keyReleased(KeyEvent arg0) {
		
	}


}



public class brickbreaker_easy_multiplayer {

	public static void main(String[] args) {
		// MultiplayerClient client = new MultiplayerClient("localhost", 5000);

		String username=args[0];
		System.out.println("Argument 1 is " +args[0]);

		JFrame obj = new JFrame();
		GamePlay_easy GamePlay_easy = new GamePlay_easy(username,"localhost", 5006,obj);
		obj.setBounds(10, 10, 700, 600);
		obj.setTitle("Brick Breaker");
		obj.setResizable(false);
		obj.setVisible(true);
		obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		obj.add(GamePlay_easy);
		//GamePlay_easy.start();
	}
}